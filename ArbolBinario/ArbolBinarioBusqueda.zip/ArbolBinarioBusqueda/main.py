from arbol import Arbol
arbolito = Arbol()

#inserciones en el árbol
arbolito.insertar(2)
arbolito.insertar(4)
arbolito.insertar(5)
arbolito.insertar(2)
arbolito.insertar(6)

#búsqueda del valor 2
print(arbolito.buscar(2))

#impresión del árbol
arbolito.imprimirArbol()