from nodo import Nodo

class Arbol:
    #método constructor
    def __init__(self):
        self.raiz = None

    #método para saber si el árbol está vacío
    def vacio(self):
        return self.raiz is None

    #método de búsqueda de valores en los nodos
    def buscar(self, valor):
        return self._buscar(self.raiz, valor)

    #método de recursividad de buscar()
    def _buscar(self, nodo, valor):
        #regresa None si no se encuentra el valor en ningún nodo
        if nodo is None:
            return None
        #regresa el valor introducido si es encontrado
        elif(nodo.valor == valor):
            return valor
        #si el valor introducido es menor, realiza búsqueda recursiva por la rama izquierda del nodo
        if valor < nodo.valor:
            return self._buscar(nodo.izquierda, valor)
        #en otro caso, realiza búsqueda recursiva por el lado derecho
        else:
            return self._buscar(nodo.derecha, valor)

    #método para insertar nodos en el árbol
    def insertar(self, valor):
        #si el árbol está vacío, el valor introducido será la raíz del árbol
        if self.vacio():
            self.raiz = Nodo(valor)
        #en otro caso se llama al método recursivo para encontrar su ubicación correcta
        else:
            self._insertar(self.raiz, valor)

    #método recursivo para insertar un valor en su ubicación correcta
    def _insertar(self, nodo, valor):
        #rama izquierda
        if valor < nodo.valor:
            if nodo.izquierda is None:
                nodo.izquierda = Nodo(valor)
            else:
                self._insertar(nodo.izquierda, valor)
        #rama derecha
        else:
            if nodo.derecha is None:
                nodo.derecha = Nodo(valor)
            else:
                self._insertar(nodo.derecha, valor)
    
    #método de impresión del árbol       
    def imprimirArbol(self):
        """ Imprime el árbol de forma jerárquica """
        self._imprimir(self.raiz)

    #método recursivo de la impresión árbol
    def _imprimir(self, nodo, nivel=0):
        """ Método recursivo para imprimir el árbol """
        if nodo is not None:
            self._imprimir(nodo.derecha, nivel + 1)  # Imprime el subárbol derecho
            print(' ' * (nivel * 3) + str(nodo.valor))  # Imprime el valor del nodo
            self._imprimir(nodo.izquierda, nivel + 1)  # Imprime el subárbol izquierdo