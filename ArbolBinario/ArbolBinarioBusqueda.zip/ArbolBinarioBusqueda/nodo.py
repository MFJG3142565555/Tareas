class Nodo:
    #método constructor
    def __init__(self, valor):
        self.valor = valor
        self.izquierda = None
        self.derecha = None